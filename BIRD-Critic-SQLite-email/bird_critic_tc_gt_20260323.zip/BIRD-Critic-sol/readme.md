# BIRD-CRITIC-1.0

A comprehensive collection of high-quality user issues encountered when developing real-world database applications. Visit our [project homepage](https://bird-critic.github.io/) and explore the [codebase](https://github.com/bird-bench/BIRD-CRITIC-1).


- **Open**: 570 cross-platform issues spanning PostgreSQL, MySQL, SQL Server, and Oracle ([HuggingFace](https://huggingface.co/datasets/birdsql/bird-critic-1.0-open))
- **PG**: 530 PostgreSQL-specific issues with comprehensive coverage ([HuggingFace](https://huggingface.co/datasets/birdsql/bird-critic-1.0-postgresql))
- **Flash**: 200 PostgreSQL-focused issues for rapid evaluation ([HuggingFace](https://huggingface.co/datasets/birdsql/bird-critic-1.0-flash-exp))
- **SQLITE**: 500 SQLite-focused issues for rapid evaluation ([HuggingFace](https://huggingface.co/datasets/birdsql/bird-critic-1.0-single-sqlite))

## Upcoming Release
We will soon release 300 additional efficiency-focused tasks to evaluate LLM performance on real-world database optimization challenges.

## Current Evaluation Notes
Please skip the following efficiency task instances, if you don't want to evaluate on efficiency:

**BIRD-CRITIC-1.0-PG:**
```
['PostgreSQL_37', 'PostgreSQL_41', 'PostgreSQL_47', 'PostgreSQL_55', 'PostgreSQL_58', 'PostgreSQL_68', 'PostgreSQL_81', 'PostgreSQL_85', 'PostgreSQL_91', 'PostgreSQL_94', 'PostgreSQL_95', 'PostgreSQL_102', 'PostgreSQL_106', 'PostgreSQL_117', 'PostgreSQL_120', 'PostgreSQL_134', 'PostgreSQL_136', 'PostgreSQL_140', 'PostgreSQL_164', 'PostgreSQL_175', 'PostgreSQL_190', 'PostgreSQL_216', 'PostgreSQL_220', 'PostgreSQL_285', 'MySQL_63', 'MySQL_71', 'Oracle_23', 'Oracle_28', 'SQLServer_2', 'SQLServer_16']
```